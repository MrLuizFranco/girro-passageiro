import React from 'react';
export default function App() { return <h1>G!rro Passageiro</h1>; }